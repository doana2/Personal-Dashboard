// Factory function using closure to manage user profile
function createUserProfile() {
  let profile = { name: '', email: '', favoriteColor: '' };
  return {
    update(field, value) { profile[field] = value; },
    getProfile() { return { ...profile }; }
  };
}

const user = createUserProfile();

// Basic email format validator
function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Validate required fields and return list of errors
function validateForm({ name, email }) {
  const errors = [];
  if (!name) errors.push("Name is required.");
  if (!email || !validateEmail(email)) errors.push("Valid email is required.");
  return errors;
}

// Display error messages in error box
function showErrors(errors) {
  const box = document.getElementById("errorBox");
  box.innerHTML = errors.map(e => `<p>${e}</p>`).join('');
  box.style.display = errors.length ? "block" : "none";
}

// Event listener to update profile
document.getElementById("profileForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const color = document.getElementById("color").value;

  const errors = validateForm({ name, email });
  showErrors(errors);
  if (errors.length) return;

  user.update('name', name);
  user.update('email', email);
  user.update('favoriteColor', color);

  displayProfile();
});

// Render profile information to the DOM
function displayProfile() {
  const { name, email, favoriteColor } = user.getProfile();
  document.getElementById("profileDisplay").innerHTML = `
    <p title="This is your name"><strong>Name:</strong> ${name}</p>
    <p title="This is your email"><strong>Email:</strong> ${email}</p>
    <p title="This is your favorite color"><strong>Favorite Color:</strong> ${favoriteColor}</p>
  `;
}

// To-do list data store
let todoList = [];

// Handle task submission
function handleAddTask() {
  const input = document.getElementById("taskInput");
  if (!input.value) return;
  todoList.push({ description: input.value, completed: false, timestamp: new Date() });
  input.value = '';
  renderTasks();
  saveToLocalStorage();
}

// Render tasks to the list
function renderTasks() {
  const list = document.getElementById("taskList");
  list.innerHTML = todoList.map(task => `
    <li class="${task.completed ? 'completed' : ''}" title="Created at ${task.timestamp.toLocaleString()}">
      ${task.description} - ${task.timestamp.toLocaleString()}
    </li>`).join('');
}

// Sort tasks by timestamp
function sortTasksByTime() {
  todoList.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
  renderTasks();
  saveToLocalStorage();
}

// Save task data to local storage
function saveToLocalStorage() {
  localStorage.setItem("todoList", JSON.stringify(todoList));
}

// Load task data from local storage on page load
function loadFromLocalStorage() {
  const data = localStorage.getItem("todoList");
  todoList = data ? JSON.parse(data).map(task => ({
    ...task,
    timestamp: new Date(task.timestamp)
  })) : [];
  renderTasks();
}

// Run once when script loads
loadFromLocalStorage();

// ================================
// New Section: Fetch External Users
// ================================
document.getElementById("fetchBtn").addEventListener("click", fetchUsers);

async function fetchUsers() {
  const container = document.getElementById("usersContainer");
  container.innerHTML = `<p>Loading data...</p>`;
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/users");
    if (!response.ok) throw new Error("Failed to fetch user data.");
    const users = await response.json();

    if (!users || users.length === 0) {
      container.innerHTML = `<p>No results found.</p>`;
      return;
    }

    container.innerHTML = users.map(user => `
      <div class="user-card" title="Click 'See Details' for more info">
        <strong>${user.name}</strong>
        <p>Email: ${user.email}</p>
        <button onclick="toggleDetails(${user.id})">See Details</button>
        <div id="details-${user.id}" class="user-details hidden">
          <p><strong>Username:</strong> ${user.username}</p>
          <p><strong>Phone:</strong> ${user.phone}</p>
          <p><strong>Website:</strong> <a href="http://${user.website}" target="_blank">${user.website}</a></p>
          <p><strong>Company:</strong> ${user.company.name}</p>
        </div>
      </div>
    `).join("");

  } catch (error) {
    container.innerHTML = `<p class="error">Error loading users: ${error.message}</p>`;
  }
}

// Toggle visibility of user detail section
function toggleDetails(id) {
  const detailsDiv = document.getElementById(`details-${id}`);
  detailsDiv.classList.toggle("hidden");
}

//  Make it available to inline HTML
window.toggleDetails = toggleDetails;

// Replace this URL with your Elastic Beanstalk live URL during deployment
const API_BASE = '/api/items';

async function fetchItems() {
  try {
    const res = await fetch(API_BASE);
    const data = await res.json();
    console.log('Fetched items:', data);
    // render your dashboard using data
  } catch (err) {
    console.error('Error fetching items:', err);
  }
}

async function addItem(newItem) {
  try {
    const res = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newItem)
    });
    const data = await res.json();
    console.log('Item added:', data);
    fetchItems(); // Refresh list
  } catch (err) {
    console.error('Error adding item:', err);
  }
}
