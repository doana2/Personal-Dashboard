const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// In-memory items array
let items = [];

// GET /api/items
app.get('/api/items', (req, res) => {
  res.json(items);
});

// POST /api/items
app.post('/api/items', (req, res) => {
  const newItem = req.body;
  items.push(newItem);
  res.status(201).json(newItem);
});

// Environment variable example
const greeting = process.env.GREETING || 'Hello from Express!';
app.get('/api/message', (req, res) => {
  res.json({ message: greeting });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
